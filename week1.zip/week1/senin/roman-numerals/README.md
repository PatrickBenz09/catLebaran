# Roman Numerals

Run code:

```sh
node roman_numerals.js
```

OR

```sh
npm start
```

Test code:
```sh
npm test
```

Make sure to run `npm install` before run the test.
