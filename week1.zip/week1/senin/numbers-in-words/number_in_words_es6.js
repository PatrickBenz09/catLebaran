console.log("ES6 compiler is starting");
let toWords = n => {
  // Your code here
};

// Driver code
console.log(toWords(1000000000000000000000));
