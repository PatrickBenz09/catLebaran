# Number In Words

Run code:

```sh
node number_in_words.js
```

OR

```sh
node number_in_words_es6.js
```

OR

```sh
npm start
```

Test code:
```sh
npm test
```

Make sure to run `npm install` or `yarn` before run the test.
