[//]: # (Ceritakan sedikit tentang latar belakangmu seperti pendidikan terakhir atau pekerjaan sebelumnya)
## Latar Belakang

Saya lulusan Binus 2016
Terakhir bekerja sebagai PHP Developer

[//]: # (Motivasi apa yang mendorongmu untuk ikut program coding bootcamp di Hacktiv8?)
## Motivasi

Ingin menambah ilmu dalam bidang web development

[//]: # (Beri tahu kami, apa yang ingin kamu dapatkan di Hacktiv8 dan apa yang ingin kamu capai setelah lulus dari sini?)
## Ekspektasi

Dapat menambah ilmu dengan efisien

[//]: # (Apakah ada hal lain yang ingin disampaikan? Bila ada, kamu bebas untuk menuliskannya)
