"use strict"

import Dice from "./dice.js"

class JSRacer {
  constructor(players, length) {
    this.players = players;
    this.length = length;
    this.board = [];
  }
  print_board() {
    for (let i = 0; i < this.players; i++) {
      this.board.push([]);
      for (let j = 0; j < this.length; j++) {
        this.board[i].push("");
      }
    }
    return this.board;
  }
  print_line(player, pos) {
    player -= 1;
    this.board[player][0] = "a"; 
  }
  player_advance(player) {
    
  }
  finished() {

  }
  winner() {

  }
  reset_board() {
    console.log("\x1B[2J")
  }
}

let race = new JSRacer(2, 5)
let dice = new Dice();

console.log(race.print_board());
console.log(race);

race.print_line(1);
console.log(race);
//console.log(race.print_line());

export default JSRacer
