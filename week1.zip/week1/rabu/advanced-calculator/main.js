'use strict'

const {Calculator} = require("./calculator.js")

// execute function on calculator.js in here
