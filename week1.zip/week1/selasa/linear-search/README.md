# Linear Search

Run code:

```sh
node linear_search.js
```

OR

```sh
npm start
```

Test code:
```sh
npm test
```

Make sure to run `npm install` before run the test.
