Array.prototype.binarySearchFast = function(search) {

};
